#custom datatype support

The examples outline how to interact with H5CPP and inherently HDF5 type system.


